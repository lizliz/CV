'''
Created on Jan 19, 2013

@author: Elizabeth Munch
emunch@albany.edu

'''

import itertools
#import matplotlib.pyplot as plt
from Wasserstein import WassDistDiagram as Wass
from Wasserstein import WassBarycenter
from Wasserstein import pointsBarycenter
#from Wasserstein import drawDiagram
import random
import numpy as np
import PlotHistogram

def checkGroupingsEqual(g1,g2):

    if len(g1)==len(g2): #no sense checking if they don't have the same length
        for g in g1:
            if not g in g2:
                return False
    else:
        return False
    
    return True

def meanMatch(match,diagramList):
    P = []
    m = 0
    for j in range(len(match)):
        if match[j] == 'Diag' or match[j] == None:
            m += 1
        else:
            P.append(diagramList[j][match[j]])
    if not len(P) == 0:              
        bary = pointsBarycenter(P,m)
            
    return bary


def DistributionOfGroupings(diagramList = [],epsilon = 1, threshold = False, numDraws = 100, perturbType = 'Gaussian'):
    '''
    Takes a set of diagrams as a list of lists of off-diagonal points.
    perturbType can be either 'Gaussian' or 'Uniform'
    Variance is only used for Gaussian distribution.
    threshold gives a value below which we don't add the point
    Returns ???
    '''
    
    def perturbUniform(point,e, beta = None):
        '''
        Returns a random point in the circle of radius epsilon 
        Returns none if the point isn't inside the circle of radius beta
        '''
        stop = False
        while not stop:
            xRand = (2*random.random()-1) * e
            yRand = (2*random.random()-1) * e
            new = [point[0]+xRand,point[1]+yRand]
                    
            if xRand**2+yRand**2 <= e**2:
                stop = True
                
        if beta:
            if not (xRand)**2+(yRand)**2<= beta**2:
                new = 'Diag'
                
        return new
        
        
        
    def perturbGauss(point,e,beta = None):
        '''
        Returns random point drawn from gaussian truncated to radius epsilon
        around each point.
        If a beta is given, only returns point if inside of radius beta
        '''
        stop = False
        while not stop:
            xRand = random.gauss(point[0],e/3.)
            yRand = random.gauss(point[1],e/3.)
            new = [xRand,yRand]
                    
            if (xRand-point[0])**2+(yRand-point[1])**2 <= e**2:
                stop = True
        
        if beta:
            if not (xRand-point[0])**2+(yRand-point[1])**2<= beta**2:
                new = 'Diag'
        
        return new
    
    
    if perturbType =='Gaussian':
        perturb = perturbGauss
    elif perturbType == 'Uniform':
        perturb = perturbUniform
    else:
        print 'You entered an incorrect choice for perturb type.\nUsing the Gaussian instead.'
    
    def singleDraw():
        newDiagList = []
        LocationsOfNewDiags = []
        
        for i in range(len(diagramList)):
            d = diagramList[i]
            newDiag = []
            for j in range(len(d)):
                x = d[j]
                
                distToDiag = (x[1]-x[0])/np.sqrt(2) 
                if distToDiag>epsilon:
                    e = epsilon
                    beta = None
                else:
                    beta = distToDiag
                    e = epsilon
                p = perturb(x,e,beta)
                if p == 'Diag':
                    LocationsOfNewDiags.append([i,j])
                newDiag.append(p)
            newDiagList.append(newDiag)
        
        return newDiagList, LocationsOfNewDiags
    
    
    
    # Draw as many times as you like and keep track of the groupings
    
    numDiagrams = len(diagramList)
    GroupingContainer = []
    
    for index in range(numDraws):
        D,LocationsOfNewDiags = singleDraw()
        
        Y,grouping = WassBarycenter(D,True)
        
        
        #if thresholding, get rid of extra matches
        if threshold:
            #threshMultiplied = np.sqrt(2)*threshold
            matchIndexToDelete = []
            for k  in range(len(grouping)):
                match = grouping[k]
                mean = meanMatch(match,diagramList)
                
                if mean[1]-mean[0]<threshold:
                    matchIndexToDelete.append(k)
            
            grouping = [grouping[k] for k in range(len(grouping)) if not k in matchIndexToDelete]
                
        
        for [i,j] in LocationsOfNewDiags:
            # jth point from diagram i was replaced with 'Diag'
            # We add it back to the grouping as being matched to the diagonal
            
            match = ['Diag' for k in range(numDiagrams)]
            match[i] = j
            
            #FIXME 
            if threshold:
                #threshMultiplied = np.sqrt(2)*threshold
                mean = meanMatch(match,diagramList)
                
                if mean[1]-mean[0]>=threshold:
                    grouping.append(match)
            else:
                grouping.append(match)
        
        
        
        
        groupingFound = False
        
        if GroupingContainer:
            for i in range(len(GroupingContainer)):
                [G,count] = GroupingContainer[i]
                # Find the grouping in the container that's the same as calculated grouping
                if checkGroupingsEqual(G,grouping):
                    GroupingContainer[i][1] += 1
                    groupingFound = True
                    break
                
            # If not found, add to Container
            if not groupingFound:
                GroupingContainer.append([grouping,1])
                    
                
        else:
            GroupingContainer.append([grouping,1])
    
    
    
    # Find diagram associated to each grouping, and return those with percentages
    distribution = []
    
    for [grouping,numEvents] in GroupingContainer:
        probability = numEvents/float(numDraws)
        
        Y = []
        
        for match in grouping:

            P = []
            m = 0
            for j in range(len(match)):
                if match[j] == 'Diag' or match[j] == None:
                    m += 1
                else:
                    P.append(diagramList[j][match[j]])
            if not len(P) == 0:              
                bary = pointsBarycenter(P,m)
                if not bary == 'Diag':
                    Y.append(bary)
        
        distribution.append([Y,probability])
    
    return distribution


if __name__ == '__main__':
    
    D1 = [[1,8],[3,6]]
    D2 = [[1,6],[3,8]]
    
    D = DistributionOfGroupings([D1,D2], threshold = .5)
    PlotHistogram.plot(D)
    
    
    
    D1 = [ [1,7], [2,2.5],[3,3.5] ]
    D2 = [ [2,7], [2,2.7]]
    D3 = [[1,8], [5,5.5]]
    
    D = DistributionOfGroupings([D1,D2,D3], threshold = 1)
    for d,y in D:
        print d 
        print y
    
