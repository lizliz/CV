'''
Created on Jul 17, 2013

@author: liz
'''

from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
import pickle


def plot(Dist):
    
    Dist.sort(key=lambda x: x[1],reverse = True)
    
    X = np.array([])
    Y = np.array([])
    Z = np.array([])
    dx = np.array([])
    dy = np.array([])
    dz = np.array([])
    colorList = []
    print len(Dist)
    for d,percent in Dist:
        color = [np.random.random() for i in range(3)]
        #print percent
        for p in d:
            a = round(p[0],1)
            b = round(p[1],1)
            
            whereX = np.where(X == a)[0]
            whereY = np.where(Y == b)[0]
            both = set(whereX).intersection(set(whereY))
            
            if both:
                last = max(both)
                height = Z[last] + dz[last]
                Z = np.append(Z,[height])
            else:
                Z = np.append(Z,[0])
            X = np.append(X, [a] )
            Y = np.append(Y, [b] )
            
            #Z = np.append(Z, [ 0 ]  )
            dx = np.append(dx, [.3])
            dy = np.append(dy, [.3])
            dz = np.append(dz, percent)
            #dz = np.append(dz, [percent])

            colorList.append(color)

    
    
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    ax.bar3d(X,Y,Z,dx,dy,dz, color = colorList)
    ax.plot([0,6],[0,6], zs=0, )
    
    xLabel = ax.set_xlabel('Birth')
    yLabel = ax.set_ylabel('Death')
    zLabel = ax.set_zlabel('Percentage')
    
    plt.show()
    
def plotOverlaid():
    
    f = open('AnnulusMeanDistribution-DoubleThresholdDiff-0.pkl','r')
    D = pickle.load(f)
    X = []
    Y = []
    for d,y in D:
        for p in d:
            X.append(p[0])
            Y.append(p[1])
    
    plt.scatter(X,Y)
    plt.axis([0,3,0,3])
    plt.show()
    
if __name__ == '__main__':
    
    
    #filename = "AnnulusMeanDistribution-Double-30Draws-100Pts-0.3epsilon.pkl"
    #filename = "AnnulusMeanDistribution-SingleThreshold-1.pkl"
    #filename = "AnnulusMeanDistribution-DoubleThreshold.3-30Draws-100Pts-0.3epsilon.pkl"



#    filename = "Distribution-Double-Diff-Threshold15.pkl"
#
#    
#    f = open(filename)
#    Dist = pickle.load(f)
#    f.close()
    
    D1 = [[3,6],[2,2.5]]
    D2 = [[3,6],[1,1.3]]
    D3 = [[3,6],[1,1.5]]
    D4 = [[3,6]]

    Dist = [  [D3, .1],[D4,.2],[D2,.25], [D1,.45],]
    #plot('AnnulusMeanDistribution-DoubleThreshold.3-30Draws-100Pts-0.3epsilon.pkl')
    plot(Dist)
    
    
    
    
    
    
    
    
    
    
    
